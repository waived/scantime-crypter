﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.PositronTheme1 = New crypter.PositronTheme()
        Me.btnProtect = New crypter.PositronButton()
        Me.PositronGroupBox3 = New crypter.PositronGroupBox()
        Me.chkUsg = New crypter.PositronCheckBox()
        Me.chkMelt = New crypter.PositronCheckBox()
        Me.chkAnti = New crypter.PositronCheckBox()
        Me.PositronGroupBox2 = New crypter.PositronGroupBox()
        Me.chkReg = New crypter.PositronCheckBox()
        Me.txtReg = New crypter.PositronTextBox()
        Me.PositronGroupBox1 = New crypter.PositronGroupBox()
        Me.PositronLabel3 = New crypter.PositronLabel()
        Me.txtName = New crypter.PositronTextBox()
        Me.chkFolder = New crypter.PositronCheckBox()
        Me.txtFolder = New crypter.PositronTextBox()
        Me.comboLocation = New crypter.PositronComboBox()
        Me.PositronLabel2 = New crypter.PositronLabel()
        Me.btnClose = New crypter.PositronControlBox()
        Me.txtIco = New crypter.PositronTextBox()
        Me.btnIco = New crypter.PositronButton()
        Me.txtExe = New crypter.PositronTextBox()
        Me.btnExe = New crypter.PositronButton()
        Me.PositronTheme1.SuspendLayout()
        Me.PositronGroupBox3.SuspendLayout()
        Me.PositronGroupBox2.SuspendLayout()
        Me.PositronGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PositronTheme1
        '
        Me.PositronTheme1.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.PositronTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.PositronTheme1.Controls.Add(Me.btnProtect)
        Me.PositronTheme1.Controls.Add(Me.PositronGroupBox3)
        Me.PositronTheme1.Controls.Add(Me.PositronGroupBox2)
        Me.PositronTheme1.Controls.Add(Me.PositronGroupBox1)
        Me.PositronTheme1.Controls.Add(Me.btnClose)
        Me.PositronTheme1.Controls.Add(Me.txtIco)
        Me.PositronTheme1.Controls.Add(Me.btnIco)
        Me.PositronTheme1.Controls.Add(Me.txtExe)
        Me.PositronTheme1.Controls.Add(Me.btnExe)
        Me.PositronTheme1.Customization = "0NDQ/2RkZP8AAAD/0tLS/9zc3P/IyMj/lpaW/w=="
        Me.PositronTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PositronTheme1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.PositronTheme1.Image = Nothing
        Me.PositronTheme1.Location = New System.Drawing.Point(0, 0)
        Me.PositronTheme1.Movable = True
        Me.PositronTheme1.Name = "PositronTheme1"
        Me.PositronTheme1.NoRounding = False
        Me.PositronTheme1.Sizable = False
        Me.PositronTheme1.Size = New System.Drawing.Size(527, 336)
        Me.PositronTheme1.SmartBounds = True
        Me.PositronTheme1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.PositronTheme1.TabIndex = 0
        Me.PositronTheme1.Text = "Boron Crypter 1.6"
        Me.PositronTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.PositronTheme1.Transparent = False
        '
        'btnProtect
        '
        Me.btnProtect.Customization = "3Nzc/8jIyP9kZGT/lpaW/8jIyP/S0tL/"
        Me.btnProtect.Font = New System.Drawing.Font("Verdana", 12.0!)
        Me.btnProtect.Image = Nothing
        Me.btnProtect.Location = New System.Drawing.Point(327, 249)
        Me.btnProtect.Name = "btnProtect"
        Me.btnProtect.NoRounding = False
        Me.btnProtect.Size = New System.Drawing.Size(180, 65)
        Me.btnProtect.TabIndex = 11
        Me.btnProtect.Text = "Protect!"
        Me.btnProtect.Transparent = False
        '
        'PositronGroupBox3
        '
        Me.PositronGroupBox3.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.PositronGroupBox3.Controls.Add(Me.chkUsg)
        Me.PositronGroupBox3.Controls.Add(Me.chkMelt)
        Me.PositronGroupBox3.Controls.Add(Me.chkAnti)
        Me.PositronGroupBox3.Customization = "lpaW/2RkZP/Q0ND/yMjI/w=="
        Me.PositronGroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.PositronGroupBox3.Image = Nothing
        Me.PositronGroupBox3.Location = New System.Drawing.Point(327, 110)
        Me.PositronGroupBox3.Movable = True
        Me.PositronGroupBox3.Name = "PositronGroupBox3"
        Me.PositronGroupBox3.NoRounding = False
        Me.PositronGroupBox3.Sizable = True
        Me.PositronGroupBox3.Size = New System.Drawing.Size(180, 122)
        Me.PositronGroupBox3.SmartBounds = True
        Me.PositronGroupBox3.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.PositronGroupBox3.TabIndex = 10
        Me.PositronGroupBox3.Text = "Options"
        Me.PositronGroupBox3.TransparencyKey = System.Drawing.Color.Empty
        Me.PositronGroupBox3.Transparent = False
        '
        'chkUsg
        '
        Me.chkUsg.BackColor = System.Drawing.Color.Gainsboro
        Me.chkUsg.Checked = False
        Me.chkUsg.Customization = "8PDw/2RkZP+vr6//yMjI/5aWlv8="
        Me.chkUsg.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkUsg.Image = Nothing
        Me.chkUsg.Location = New System.Drawing.Point(21, 87)
        Me.chkUsg.Name = "chkUsg"
        Me.chkUsg.NoRounding = False
        Me.chkUsg.Size = New System.Drawing.Size(130, 22)
        Me.chkUsg.TabIndex = 18
        Me.chkUsg.Text = "USG"
        Me.chkUsg.Transparent = False
        '
        'chkMelt
        '
        Me.chkMelt.BackColor = System.Drawing.Color.Gainsboro
        Me.chkMelt.Checked = False
        Me.chkMelt.Customization = "8PDw/2RkZP+vr6//yMjI/5aWlv8="
        Me.chkMelt.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkMelt.Image = Nothing
        Me.chkMelt.Location = New System.Drawing.Point(20, 58)
        Me.chkMelt.Name = "chkMelt"
        Me.chkMelt.NoRounding = False
        Me.chkMelt.Size = New System.Drawing.Size(100, 22)
        Me.chkMelt.TabIndex = 17
        Me.chkMelt.Text = "Melt"
        Me.chkMelt.Transparent = False
        '
        'chkAnti
        '
        Me.chkAnti.BackColor = System.Drawing.Color.Gainsboro
        Me.chkAnti.Checked = False
        Me.chkAnti.Customization = "8PDw/2RkZP+vr6//yMjI/5aWlv8="
        Me.chkAnti.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkAnti.Image = Nothing
        Me.chkAnti.Location = New System.Drawing.Point(21, 30)
        Me.chkAnti.Name = "chkAnti"
        Me.chkAnti.NoRounding = False
        Me.chkAnti.Size = New System.Drawing.Size(130, 22)
        Me.chkAnti.TabIndex = 16
        Me.chkAnti.Text = "Anti VM / sandbox"
        Me.chkAnti.Transparent = False
        '
        'PositronGroupBox2
        '
        Me.PositronGroupBox2.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.PositronGroupBox2.Controls.Add(Me.chkReg)
        Me.PositronGroupBox2.Controls.Add(Me.txtReg)
        Me.PositronGroupBox2.Customization = "lpaW/2RkZP/Q0ND/yMjI/w=="
        Me.PositronGroupBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.PositronGroupBox2.Image = Nothing
        Me.PositronGroupBox2.Location = New System.Drawing.Point(21, 249)
        Me.PositronGroupBox2.Movable = True
        Me.PositronGroupBox2.Name = "PositronGroupBox2"
        Me.PositronGroupBox2.NoRounding = False
        Me.PositronGroupBox2.Sizable = True
        Me.PositronGroupBox2.Size = New System.Drawing.Size(286, 65)
        Me.PositronGroupBox2.SmartBounds = True
        Me.PositronGroupBox2.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.PositronGroupBox2.TabIndex = 9
        Me.PositronGroupBox2.Text = "Persistence (Registry)"
        Me.PositronGroupBox2.TransparencyKey = System.Drawing.Color.Empty
        Me.PositronGroupBox2.Transparent = False
        '
        'chkReg
        '
        Me.chkReg.BackColor = System.Drawing.Color.Gainsboro
        Me.chkReg.Checked = False
        Me.chkReg.Customization = "8PDw/2RkZP+vr6//yMjI/5aWlv8="
        Me.chkReg.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkReg.Image = Nothing
        Me.chkReg.Location = New System.Drawing.Point(18, 30)
        Me.chkReg.Name = "chkReg"
        Me.chkReg.NoRounding = False
        Me.chkReg.Size = New System.Drawing.Size(74, 22)
        Me.chkReg.TabIndex = 12
        Me.chkReg.Text = "HKCU"
        Me.chkReg.Transparent = False
        '
        'txtReg
        '
        Me.txtReg.Customization = "0tLS/8jIyP+Wlpb/"
        Me.txtReg.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtReg.Image = Nothing
        Me.txtReg.Location = New System.Drawing.Point(98, 28)
        Me.txtReg.MaxLength = 32767
        Me.txtReg.Multiline = False
        Me.txtReg.Name = "txtReg"
        Me.txtReg.NoRounding = False
        Me.txtReg.ReadOnly = False
        Me.txtReg.Size = New System.Drawing.Size(169, 24)
        Me.txtReg.TabIndex = 13
        Me.txtReg.Text = "Yahoo Search Manager"
        Me.txtReg.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtReg.Transparent = False
        Me.txtReg.UseSystemPasswordChar = False
        '
        'PositronGroupBox1
        '
        Me.PositronGroupBox1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.PositronGroupBox1.Controls.Add(Me.PositronLabel3)
        Me.PositronGroupBox1.Controls.Add(Me.txtName)
        Me.PositronGroupBox1.Controls.Add(Me.chkFolder)
        Me.PositronGroupBox1.Controls.Add(Me.txtFolder)
        Me.PositronGroupBox1.Controls.Add(Me.comboLocation)
        Me.PositronGroupBox1.Controls.Add(Me.PositronLabel2)
        Me.PositronGroupBox1.Customization = "lpaW/2RkZP/Q0ND/yMjI/w=="
        Me.PositronGroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.PositronGroupBox1.Image = Nothing
        Me.PositronGroupBox1.Location = New System.Drawing.Point(21, 110)
        Me.PositronGroupBox1.Movable = True
        Me.PositronGroupBox1.Name = "PositronGroupBox1"
        Me.PositronGroupBox1.NoRounding = False
        Me.PositronGroupBox1.Sizable = True
        Me.PositronGroupBox1.Size = New System.Drawing.Size(286, 122)
        Me.PositronGroupBox1.SmartBounds = True
        Me.PositronGroupBox1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.PositronGroupBox1.TabIndex = 8
        Me.PositronGroupBox1.Text = "Installation"
        Me.PositronGroupBox1.TransparencyKey = System.Drawing.Color.Empty
        Me.PositronGroupBox1.Transparent = False
        '
        'PositronLabel3
        '
        Me.PositronLabel3.AutoSize = True
        Me.PositronLabel3.BackColor = System.Drawing.Color.Transparent
        Me.PositronLabel3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.PositronLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.PositronLabel3.Location = New System.Drawing.Point(15, 90)
        Me.PositronLabel3.Name = "PositronLabel3"
        Me.PositronLabel3.Size = New System.Drawing.Size(65, 13)
        Me.PositronLabel3.TabIndex = 11
        Me.PositronLabel3.Text = "Exe Name"
        '
        'txtName
        '
        Me.txtName.Customization = "0tLS/8jIyP+Wlpb/"
        Me.txtName.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtName.Image = Nothing
        Me.txtName.Location = New System.Drawing.Point(98, 85)
        Me.txtName.MaxLength = 32767
        Me.txtName.Multiline = False
        Me.txtName.Name = "txtName"
        Me.txtName.NoRounding = False
        Me.txtName.ReadOnly = False
        Me.txtName.Size = New System.Drawing.Size(169, 24)
        Me.txtName.TabIndex = 10
        Me.txtName.Text = "setup_x86.exe"
        Me.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtName.Transparent = False
        Me.txtName.UseSystemPasswordChar = False
        '
        'chkFolder
        '
        Me.chkFolder.BackColor = System.Drawing.Color.Gainsboro
        Me.chkFolder.Checked = False
        Me.chkFolder.Customization = "8PDw/2RkZP+vr6//yMjI/5aWlv8="
        Me.chkFolder.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkFolder.Image = Nothing
        Me.chkFolder.Location = New System.Drawing.Point(18, 57)
        Me.chkFolder.Name = "chkFolder"
        Me.chkFolder.NoRounding = False
        Me.chkFolder.Size = New System.Drawing.Size(74, 22)
        Me.chkFolder.TabIndex = 9
        Me.chkFolder.Text = "Folder"
        Me.chkFolder.Transparent = False
        '
        'txtFolder
        '
        Me.txtFolder.Customization = "0tLS/8jIyP+Wlpb/"
        Me.txtFolder.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtFolder.Image = Nothing
        Me.txtFolder.Location = New System.Drawing.Point(98, 55)
        Me.txtFolder.MaxLength = 32767
        Me.txtFolder.Multiline = False
        Me.txtFolder.Name = "txtFolder"
        Me.txtFolder.NoRounding = False
        Me.txtFolder.ReadOnly = False
        Me.txtFolder.Size = New System.Drawing.Size(169, 24)
        Me.txtFolder.TabIndex = 9
        Me.txtFolder.Text = "Yahoo_Toolbar_10.1.22.0"
        Me.txtFolder.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtFolder.Transparent = False
        Me.txtFolder.UseSystemPasswordChar = False
        '
        'comboLocation
        '
        Me.comboLocation.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.comboLocation.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.comboLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboLocation.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.comboLocation.FormattingEnabled = True
        Me.comboLocation.Items.AddRange(New Object() {"AppData (Roaming)", "AppData (Microsoft)", "User Profile", "Downloads", "Favorites", "Temporary Files"})
        Me.comboLocation.Location = New System.Drawing.Point(98, 28)
        Me.comboLocation.Name = "comboLocation"
        Me.comboLocation.Size = New System.Drawing.Size(169, 21)
        Me.comboLocation.StartIndex = 0
        Me.comboLocation.TabIndex = 9
        '
        'PositronLabel2
        '
        Me.PositronLabel2.AutoSize = True
        Me.PositronLabel2.BackColor = System.Drawing.Color.Transparent
        Me.PositronLabel2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.PositronLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Me.PositronLabel2.Location = New System.Drawing.Point(15, 31)
        Me.PositronLabel2.Name = "PositronLabel2"
        Me.PositronLabel2.Size = New System.Drawing.Size(54, 13)
        Me.PositronLabel2.TabIndex = 9
        Me.PositronLabel2.Text = "Location"
        '
        'btnClose
        '
        Me.btnClose.Customization = "3Nzc/8jIyP9kZGT/lpaW/8jIyP/S0tL/"
        Me.btnClose.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnClose.Image = Nothing
        Me.btnClose.Location = New System.Drawing.Point(499, 3)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.NoRounding = False
        Me.btnClose.Size = New System.Drawing.Size(22, 22)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "PositronControlBox1"
        Me.btnClose.Transparent = False
        '
        'txtIco
        '
        Me.txtIco.Customization = "0tLS/8jIyP+Wlpb/"
        Me.txtIco.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtIco.Image = Nothing
        Me.txtIco.Location = New System.Drawing.Point(119, 68)
        Me.txtIco.MaxLength = 32767
        Me.txtIco.Multiline = False
        Me.txtIco.Name = "txtIco"
        Me.txtIco.NoRounding = False
        Me.txtIco.ReadOnly = True
        Me.txtIco.Size = New System.Drawing.Size(388, 24)
        Me.txtIco.TabIndex = 3
        Me.txtIco.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtIco.Transparent = False
        Me.txtIco.UseSystemPasswordChar = False
        '
        'btnIco
        '
        Me.btnIco.Customization = "3Nzc/8jIyP9kZGT/lpaW/8jIyP/S0tL/"
        Me.btnIco.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnIco.Image = Nothing
        Me.btnIco.Location = New System.Drawing.Point(21, 68)
        Me.btnIco.Name = "btnIco"
        Me.btnIco.NoRounding = False
        Me.btnIco.Size = New System.Drawing.Size(92, 24)
        Me.btnIco.TabIndex = 2
        Me.btnIco.Text = "Select Icon"
        Me.btnIco.Transparent = False
        '
        'txtExe
        '
        Me.txtExe.Customization = "0tLS/8jIyP+Wlpb/"
        Me.txtExe.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtExe.Image = Nothing
        Me.txtExe.Location = New System.Drawing.Point(119, 38)
        Me.txtExe.MaxLength = 32767
        Me.txtExe.Multiline = False
        Me.txtExe.Name = "txtExe"
        Me.txtExe.NoRounding = False
        Me.txtExe.ReadOnly = True
        Me.txtExe.Size = New System.Drawing.Size(388, 24)
        Me.txtExe.TabIndex = 1
        Me.txtExe.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtExe.Transparent = False
        Me.txtExe.UseSystemPasswordChar = False
        '
        'btnExe
        '
        Me.btnExe.Customization = "3Nzc/8jIyP9kZGT/lpaW/8jIyP/S0tL/"
        Me.btnExe.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnExe.Image = Nothing
        Me.btnExe.Location = New System.Drawing.Point(21, 38)
        Me.btnExe.Name = "btnExe"
        Me.btnExe.NoRounding = False
        Me.btnExe.Size = New System.Drawing.Size(92, 24)
        Me.btnExe.TabIndex = 0
        Me.btnExe.Text = "Select Exe"
        Me.btnExe.Transparent = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(527, 336)
        Me.Controls.Add(Me.PositronTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.PositronTheme1.ResumeLayout(False)
        Me.PositronGroupBox3.ResumeLayout(False)
        Me.PositronGroupBox2.ResumeLayout(False)
        Me.PositronGroupBox1.ResumeLayout(False)
        Me.PositronGroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PositronTheme1 As PositronTheme
    Friend WithEvents txtIco As PositronTextBox
    Friend WithEvents btnIco As PositronButton
    Friend WithEvents txtExe As PositronTextBox
    Friend WithEvents btnExe As PositronButton
    Friend WithEvents btnClose As PositronControlBox
    Friend WithEvents PositronGroupBox1 As PositronGroupBox
    Friend WithEvents comboLocation As PositronComboBox
    Friend WithEvents PositronLabel2 As PositronLabel
    Friend WithEvents chkFolder As PositronCheckBox
    Friend WithEvents txtFolder As PositronTextBox
    Friend WithEvents PositronGroupBox3 As PositronGroupBox
    Friend WithEvents PositronGroupBox2 As PositronGroupBox
    Friend WithEvents chkReg As PositronCheckBox
    Friend WithEvents txtReg As PositronTextBox
    Friend WithEvents PositronLabel3 As PositronLabel
    Friend WithEvents txtName As PositronTextBox
    Friend WithEvents btnProtect As PositronButton
    Friend WithEvents chkUsg As PositronCheckBox
    Friend WithEvents chkMelt As PositronCheckBox
    Friend WithEvents chkAnti As PositronCheckBox
End Class
